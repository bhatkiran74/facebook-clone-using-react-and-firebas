import React from 'react'
import "./Widgets.css"


function Widgets() {
    return (
        <div className="widgets">


            <h4>hello</h4>


        </div>
    )
}

export default Widgets
