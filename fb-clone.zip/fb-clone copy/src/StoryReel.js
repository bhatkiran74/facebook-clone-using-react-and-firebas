import React from 'react'
import Story from './Story';

import "./StoryReel.css";

function StoryReel() {
    return (
        <div className="storyReel">

        <Story image="https://images.unsplash.com/photo-1505632958218-4f23394784a6?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=80" profileSrc="https://images.unsplash.com/photo-1505632958218-4f23394784a6?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=80"  title="kiran bhat" />
        <Story image="https://images.unsplash.com/photo-1599968125179-0b70eda83533?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=334&q=80" profileSrc="https://images.unsplash.com/photo-1505632958218-4f23394784a6?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=80"  title="kiran bhat" />
        <Story image="https://images.unsplash.com/photo-1599901470329-7e3e8ca3a611?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=334&q=80" profileSrc="https://images.unsplash.com/photo-1505632958218-4f23394784a6?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=80"  title="kiran bhat" />
        
        <Story image="https://images.unsplash.com/photo-1599981903192-1b95db0355a2?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1534&q=80" profileSrc="https://images.unsplash.com/photo-1505632958218-4f23394784a6?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=80"  title="kiran bhat" />


        <Story image="https://images.unsplash.com/photo-1599968125179-0b70eda83533?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=334&q=80" profileSrc="https://images.unsplash.com/photo-1505632958218-4f23394784a6?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=80"  title="kiran bhat" />






            {/* story */}
            {/* story */}
            {/* story */}
            {/* story */}
            {/* story */}
            {/* story */}
        </div>
    )
}

export default StoryReel
