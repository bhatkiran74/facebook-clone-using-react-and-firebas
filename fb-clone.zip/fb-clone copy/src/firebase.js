import firebase from 'firebase'



// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyAAlNoXVLqe0lJ4ZA5Dka_Ji2KvldD0-kQ",
    authDomain: "facebook-clone-b2659.firebaseapp.com",
    databaseURL: "https://facebook-clone-b2659.firebaseio.com",
    projectId: "facebook-clone-b2659",
    storageBucket: "facebook-clone-b2659.appspot.com",
    messagingSenderId: "278116768422",
    appId: "1:278116768422:web:0df4daec08237f520f7267",
    measurementId: "G-L2YYD7PH5B"
  };



  const firebaseApp = firebase.initializeApp(firebaseConfig)
  const db = firebaseApp.firestore()
  const auth = firebase.auth()

  const provider = new firebase.auth.GoogleAuthProvider()



  export { auth , provider}
  export default db 